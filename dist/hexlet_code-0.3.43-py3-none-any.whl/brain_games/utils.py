from random import randint


def get_rnd_num(start=2, end=25):
    return randint(start, end)
