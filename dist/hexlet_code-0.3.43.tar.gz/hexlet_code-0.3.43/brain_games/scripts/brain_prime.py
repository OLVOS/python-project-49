#!/usr/bin/env python3
from brain_games.games.game_prime import run_game_prime


def main():
    run_game_prime()


if __name__ == '__main__':
    main()
